# Publish this static site on GitHub Pages

1. Upload the **contents** of this folder to the root of your public GitHub repository's `main` branch (not inside a nested `siyaq-work-english/` folder).
2. In repository **Settings → Pages → Build and deployment**, set **Source = Deploy from a branch**, **Branch = main**, **Folder = /(root)**, then Save.
3. After GitHub reports deployment complete, open your repository's Pages address. Note: the iPhone Safari microphone and speech controls still require real-device testing.

No npm build step is needed. Do not upload browser data or secrets. The `.nojekyll` file disables GitHub Pages' Jekyll processing for this static site.
