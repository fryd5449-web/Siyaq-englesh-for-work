import { tracks, lessons, getLesson, getTrack, lessonSteps } from './data.js';

const KEY = 'siyaq-progress-v1';
const byId = id => document.getElementById(id);
const esc = str => String(str ?? '').replace(/[&<>"']/g, ch => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[ch]));
const today = () => { const d = new Date(); return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`; };
const icons = {
  home:'<path d="m3 10 9-7 9 7v10a1 1 0 0 1-1 1h-5v-7H9v7H4a1 1 0 0 1-1-1Z"/>',
  book:'<path d="M12 7v14M3 18V5a2 2 0 0 1 2-2h4a3 3 0 0 1 3 3 3 3 0 0 1 3-3h4a2 2 0 0 1 2 2v13h-6a3 3 0 0 0-3 3 3 3 0 0 0-3-3Z"/>',
  repeat:'<path d="m17 2 4 4-4 4M3 11V9a3 3 0 0 1 3-3h15M7 22l-4-4 4-4m14-1v2a3 3 0 0 1-3 3H3"/>',
  chart:'<path d="M3 3v18h18M7 16v-4m5 4V7m5 9V4"/>',
  arrow:'<path d="m14 7-5 5 5 5M20 12H9"/>',
  chevron:'<path d="m15 18-6-6 6-6"/>',
  check:'<path d="m5 12 4 4L19 6"/>',
  message:'<path d="M21 11.5a8.4 8.4 0 0 1-.9 3.8A8.5 8.5 0 0 1 12.5 20a8.4 8.4 0 0 1-3.8-.9L3 21l1.9-5.7a8.4 8.4 0 0 1-.9-3.8A8.5 8.5 0 0 1 12.5 3 8.5 8.5 0 0 1 21 11.5Z"/>',
  users:'<path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2m7-10a4 4 0 1 0 0-8 4 4 0 0 0 0 8Zm9 10v-2a4 4 0 0 0-3-3.9M16 3.1a4 4 0 0 1 0 7.8"/>',
  headset:'<path d="M3 14v-3a9 9 0 0 1 18 0v3m-2 5h-2v-7h4v5a2 2 0 0 1-2 2Zm-14 0h2v-7H3v5a2 2 0 0 0 2 2Zm14 0a4 4 0 0 1-4 3h-2"/>',
  mail:'<rect x="3" y="5" width="18" height="14" rx="2"/><path d="m3 7 9 7 9-7"/>',
  puzzle:'<path d="M8 3H5a2 2 0 0 0-2 2v3h2a2 2 0 0 1 0 4H3v7a2 2 0 0 0 2 2h5v-2a2 2 0 0 1 4 0v2h5a2 2 0 0 0 2-2v-5h-2a2 2 0 0 1 0-4h2V5a2 2 0 0 0-2-2h-7v2a2 2 0 0 1-4 0Z"/>',
  briefcase:'<rect x="3" y="7" width="18" height="14" rx="2"/><path d="M8 7V5a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2M3 12a20 20 0 0 0 18 0M12 12v3"/>',
  target:'<circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="5"/><circle cx="12" cy="12" r="1"/>',
  clock:'<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
  medal:'<circle cx="12" cy="8" r="5"/><path d="m8.5 12-2 9L12 18l5.5 3-2-9"/>',
  pen:'<path d="m15 5 4 4M4 20l4.5-1 11-11a2.8 2.8 0 0 0-4-4l-11 11Z"/>',
  headphones:'<path d="M3 14v-3a9 9 0 0 1 18 0v3M3 14h4v7H5a2 2 0 0 1-2-2Zm18 0h-4v7h2a2 2 0 0 0 2-2Z"/>',
  mic:'<rect x="9" y="2" width="6" height="13" rx="3"/><path d="M5 11a7 7 0 0 0 14 0m-7 7v4m-4 0h8"/>',
  volume:'<path d="M11 5 6 9H3v6h3l5 4V5Zm4 4a4 4 0 0 1 0 6m3-9a8 8 0 0 1 0 12"/>',
  spark:'<path d="m12 2 1.7 6.3L20 10l-6.3 1.7L12 18l-1.7-6.3L4 10l6.3-1.7ZM19 18l.6 2.4L22 21l-2.4.6L19 24l-.6-2.4L16 21l2.4-.6Z"/>',
  info:'<circle cx="12" cy="12" r="10"/><path d="M12 11v6m0-10h.01"/>',
  lock:'<rect x="5" y="10" width="14" height="12" rx="2"/><path d="M8 10V7a4 4 0 0 1 8 0v3"/>',
  refresh:'<path d="M20 11a8 8 0 1 0-2 6m2-10v4h-4"/>',
  layers:'<path d="m12 2 9 5-9 5-9-5 9-5Zm-9 10 9 5 9-5M3 17l9 5 9-5"/>',
  alert:'<path d="m12 3 10 18H2L12 3Zm0 7v4m0 3h.01"/>',
  trophy:'<path d="M8 21h8M12 17v4M7 3h10v7a5 5 0 0 1-10 0V3ZM7 5H3v3a4 4 0 0 0 4 4m10-7h4v3a4 4 0 0 1-4 4"/>',
  calendar:'<rect x="3" y="5" width="18" height="16" rx="2"/><path d="M7 3v4m10-4v4M3 10h18"/>'
};
const ico = (name, size=20) => `<svg aria-hidden="true" width="${size}" height="${size}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round">${icons[name] || icons.spark}</svg>`;
const allowedLessonIds = new Set(lessons.map(x => x.id));
const allowedMistakeIds = new Set(lessons.flatMap(l => lessonSteps(l).map(s=>`${l.id}:${s.type}:${s.index}`)));
const safeNumber = (n,max=100000) => Number.isSafeInteger(n) && n>=0 && n<=max ? n : 0;
const dateKey = v => /^\d{4}-\d{2}-\d{2}$/.test(v) && !Number.isNaN(new Date(`${v}T12:00:00`).getTime());
function loadProgress(){
  const blank = {completed:{},mistakes:{},activity:{},totals:{attempts:0,correct:0,manual:0}};
  try {
    const saved = JSON.parse(localStorage.getItem(KEY) || 'null');
    if (!saved || typeof saved !== 'object' || Array.isArray(saved)) return blank;
    if(saved.completed && typeof saved.completed === 'object') for(const [id,p] of Object.entries(saved.completed)){
      if(allowedLessonIds.has(id) && p && typeof p==='object'){
        const max = lessonSteps(getLesson(id)).length;
        blank.completed[id] = {score:Math.min(safeNumber(p.score),max),max,doneAt:dateKey(p.doneAt)?p.doneAt:today()};
      }
    }
    if(saved.mistakes && typeof saved.mistakes === 'object') for(const [id,p] of Object.entries(saved.mistakes)){
      if(allowedMistakeIds.has(id))blank.mistakes[id]={date:dateKey(p?.date)?p.date:today()};
    }
    if(saved.activity && typeof saved.activity === 'object')for(const [date,count] of Object.entries(saved.activity)){
      if(dateKey(date) && date.length===10) blank.activity[date]=safeNumber(count);
    }
    if(saved.totals && typeof saved.totals ==='object') for(const k of ['attempts','correct','manual']) blank.totals[k]=safeNumber(saved.totals[k]);
  } catch(_e) { /* Invalid or unavailable local storage never prevents learning. */ }
  return blank;
}
const progress = loadProgress();
const app = byId('app');
const live = byId('announcer');
const state = {session:null,selected:[],bank:[],choice:null,feedback:null,typed:'',fallback:false,recorder:null,recording:false,heard:false,transcript:'',speechError:'',audioError:'',storageAvailable:true};
function saveProgress(){
  try{localStorage.setItem(KEY,JSON.stringify(progress));state.storageAvailable=true;}
  catch(_e){state.storageAvailable=false;}
}
const lessonCompleted = id => !!progress.completed[id];
const countDone = trackId => lessons.filter(l=>l.track===trackId && lessonCompleted(l.id)).length;
const nextLesson = () => lessons.find(l=>!lessonCompleted(l.id)) || lessons[0];
const mistakeCount = () => Object.keys(progress.mistakes).length;
const accuracy = () => progress.totals.attempts ? Math.round(progress.totals.correct/progress.totals.attempts*100) : 0;
const countActiveDays = () => Object.keys(progress.activity).filter(d=>progress.activity[d]>0).length;
function localDate(date){return new Date(`${date}T12:00:00`).toLocaleDateString('ar-SA',{day:'numeric',month:'short',year:'numeric'});}
function renderNav(page){
  const active = page==='practice'||page==='lesson'||page==='track'?'tracks':page==='summary'?(state.session?.mode==='review'?'review':'tracks'):page;
  document.querySelectorAll('[data-nav],[data-mobile-nav]').forEach(n=>{
    const yes=(n.dataset.nav||n.dataset.mobileNav)===active;
    n.classList.toggle('active',yes);
    if(yes)n.setAttribute('aria-current','page');else n.removeAttribute('aria-current');
  });
  const badge=byId('mistakes-count');badge.hidden=!mistakeCount();badge.textContent=String(mistakeCount());
}
function currentRoute(){
 let hash='';try{hash=decodeURIComponent(location.hash.slice(1));}catch(_e){return {name:'home'};}const [name,id]=hash.split('/');
 if(name==='track'&&getTrack(id))return {name,id};
 if(name==='lesson'&&getLesson(id))return {name,id};
 if(['home','tracks','review','progress','practice','summary'].includes(name))return {name};
 return {name:'home'};
}
const crumb = (label,href) => `<a href="${href}" class="back-link">${ico('arrow',15)} ${esc(label)}</a>`;
const sectionHeading = (heading,detail,linkText,href) => `<div class="section-head"><div><h2>${esc(heading)}</h2><p>${esc(detail)}</p></div>${href?`<a href="${href}" class="text-link">${esc(linkText)} ${ico('chevron')}</a>`:''}</div>`;
function trackCard(t){const done=countDone(t.id),total=lessons.filter(l=>l.track===t.id).length;return `<a href="#track/${t.id}" class="track-card tone-${esc(t.tone)}" data-testid="track-${t.id}"><div class="track-top"><span class="track-symbol">${ico(t.icon)}</span><span class="track-number">${t.number} / 06</span></div><h3>${esc(t.title)}</h3><div class="track-en" lang="en">${esc(t.en)}</div><p>${esc(t.desc)}</p><div class="track-bottom"><span class="track-progress"><span class="mini-progress"><i class="bar-${Math.round(done/total*100)}"></i></span>${done} / ${total} دروس</span><span class="arrow-box">${ico('chevron',15)}</span></div></a>`;}
function renderHome(){const next=nextLesson(),done=Object.keys(progress.completed).length;return `<div class="hero"><div class="hero-copy"><div class="hero-kicker"><span class="spark">✳</span> اللغة التي تستخدمها في يومك</div><h1>مو بس تفهم الإنجليزية.<br/><em>خلّك تعرف ترد.</em></h1><p>تعلّم كيف تبدأ محادثة، تختار التعبير الصحيح، وتتكلم بثقة في المواقف اليومية داخل العمل.</p><button class="btn btn-primary" data-action="open-lesson" data-id="${next.id}">${done?'واصل رحلتك':'ابدأ أول درس'} ${ico('arrow',17)}</button></div><div class="hero-visual" aria-label="مثال على محادثة عمل باللغة الإنجليزية"><div class="visual-sheet"><div class="sheet-top"><span class="sheet-caption">REAL WORK CONVERSATION</span><span class="sheet-avatar">S</span></div><div class="sheet-bubble">Could you share the updated report?</div><div class="sheet-bubble mine">Of course. I'll send it by 3 p.m.</div><div class="sheet-check"><span class="check-circle">✓</span><span>Clear. Professional. Natural.</span></div></div><span class="visual-float float-one">✦ <strong>Build sentences</strong></span><span class="visual-float float-two">↗ <strong>Speak with confidence</strong></span></div></div>
<div class="metric-grid"><div class="metric-card"><div><div class="metric-label">دروس أنهيتها</div><div class="metric-value">${done}<span class="metric-unit"> / ${lessons.length}</span></div></div><span class="metric-icon">${ico('book')}</span></div><div class="metric-card"><div><div class="metric-label">دقة الإجابات</div><div class="metric-value">${accuracy()}<span class="metric-unit">%</span></div></div><span class="metric-icon">${ico('target')}</span></div><div class="metric-card"><div><div class="metric-label">أيام تدربت فيها</div><div class="metric-value">${countActiveDays()}<span class="metric-unit">يوم</span></div></div><span class="metric-icon">${ico('calendar')}</span></div></div>
${sectionHeading('اختر موقفك، وابدأ الحديث','6 مسارات عملية · 18 درسًا · مستوى متوسط','عرض المسارات','#tracks')}<div class="track-grid">${tracks.map(trackCard).join('')}</div><div class="learning-tip"><span class="tip-icon">${ico('spark',21)}</span><div><h3>لا تحفظ جملة بدون سياق</h3><p>كل درس يشرح التعبير أولًا، ثم يدربك على ترتيب الكلمات والمحادثة والكتابة والاستماع والتحدث.</p></div></div>${!state.storageAvailable?`<div class="notice">تعذر الحفظ على هذا المتصفح. التمارين تعمل، لكن قد لا يبقى التقدم بعد إغلاق الصفحة.</div>`:''}`;}
function renderTracks(){return `<div class="page-title"><div class="eyebrow">YOUR LEARNING PATH</div><h1>مسارات الإنجليزية في العمل</h1><p>ابدأ بالموقف الذي يتكرر عندك. كل مسار فيه 3 دروس وحوارات كاملة.</p></div><div class="track-grid">${tracks.map(trackCard).join('')}</div>`;}
function renderTrack(trackId){const t=getTrack(trackId);return `${crumb('جميع المسارات','#tracks')}<div class="page-title"><div class="eyebrow">${t.number} / 06 · ${esc(t.en)}</div><h1>${esc(t.title)}</h1><p>${esc(t.desc)}</p></div><div class="lesson-grid">${lessons.filter(l=>l.track===trackId).map((l,i)=>`<button class="lesson-card" data-action="open-lesson" data-id="${l.id}"><span class="lesson-order">الدرس ${String(i+1).padStart(2,'0')} ${lessonCompleted(l.id)?'· مكتمل ✓':''}</span><h3>${esc(l.title)}</h3><span class="track-en" lang="en">${esc(l.en)}</span><p>${esc(l.situation)}</p><div class="lesson-footer"><span>${lessonCompleted(l.id)?'أعد التدريب':'افتح الدرس'}</span><span class="lesson-badge">8 تمارين</span></div></button>`).join('')}</div>`;}
function renderOverview(id){const l=getLesson(id),t=getTrack(l.track);return `${crumb('العودة إلى المسار',`#track/${t.id}`)}<div class="overview-head"><div class="eyebrow">${esc(t.title)} · ${esc(t.en)}</div><h1>${esc(l.title)}</h1><p>${esc(l.objective)}</p><div class="overview-meta"><span class="meta-chip">${ico('message',13)} موقف عملي كامل</span><span class="meta-chip">${ico('clock',13)} نحو 8–12 دقيقة</span><span class="meta-chip">8 تمارين تفاعلية</span>${lessonCompleted(l.id)?'<span class="meta-chip">✓ أكملت هذا الدرس</span>':''}</div></div><div class="concept-box"><h2>قبل ما تبدأ — فهم التعبير</h2><p>${esc(l.rule)}</p><div class="examples"><div class="example bad" lang="en"><small>✕ صياغة شائعة غير صحيحة</small>${esc(l.bad)}</div><div class="example good" lang="en"><small>✓ الصياغة الطبيعية</small>${esc(l.good)}</div></div><div class="notice"><strong>الموقف:</strong> ${esc(l.situation)}</div><div class="overview-actions"><button class="btn btn-primary" data-action="start-lesson" data-id="${l.id}">${lessonCompleted(l.id)?'تدرب من جديد':'ابدأ التمارين'} ${ico('arrow')}</button><a href="#tracks" class="btn btn-outline">استعرض المسارات</a></div></div>`;}
function typeName(t){return ({order:'ترتيب الكلمات',dialogue:'محادثة تفاعلية',writing:'كتابة جملة',listening:'فهم المسموع',speaking:'التحدث بالنص'})[t] || t;}
function typeIcon(t){return ({order:'layers',dialogue:'message',writing:'pen',listening:'headphones',speaking:'mic'})[t] || 'book';}
function makeStepKey(s){return `${s.lessonId}:${s.type}:${s.index}`;}
function activeStep(){return state.session?.steps[state.session.index];}
function getStepExercise(step){const l=getLesson(step.lessonId);return step.type==='order'?l.order[step.index]:step.type==='dialogue'?l.dialogue[step.index]:l[step.type];}
function seededShuffle(words){
  const a=words.map((text,id)=>({text,id}));for(let i=a.length-1;i>0;i--){const j=Math.floor(Math.random()*(i+1));[a[i],a[j]]=[a[j],a[i]];}
  if(a.map(x=>x.text).join(' ')===words.join(' '))a.reverse();return a;
}
function resetStage(){
  state.writingReview=false;state.selected=[];state.choice=null;state.feedback=null;state.typed='';state.fallback=false;state.heard=false;state.transcript='';state.speechError='';state.audioError='';state.recording=false;
  const s=activeStep();state.bank=s?.type==='order'?seededShuffle(getStepExercise(s).words):[];
}
function stopSpeech(){
 if(state.recorder){try{state.recorder.onresult=null;state.recorder.onerror=null;state.recorder.onend=null;state.recorder.abort();}catch(_e){}state.recorder=null;}
 state.recording=false;try{window.speechSynthesis?.cancel();}catch(_e){}
}
function startSession(id,mode='lesson',requestedSteps=null){stopSpeech();const steps=requestedSteps || lessonSteps(getLesson(id)).map(s=>({...s,lessonId:id}));state.session={lessonId:id,mode,steps,index:0,correct:0,manual:0,attempts:0};resetStage();location.hash='#practice';render();window.scrollTo(0,0);}
function markAttempt(correct,manual=false){
 const s=activeStep(),key=makeStepKey(s),sess=state.session;
 if(manual){sess.manual++;progress.totals.manual++;}
 else{sess.attempts++;progress.totals.attempts++;if(correct){sess.correct++;progress.totals.correct++;}}
 if(correct)delete progress.mistakes[key];else if(!manual)progress.mistakes[key]={date:today()};
 progress.activity[today()]=(progress.activity[today()]||0)+1;saveProgress();
}
function setFeedback({correct,manual=false,title,body,model}){
 if(state.feedback?.resolved)return;
 markAttempt(correct,manual);
 state.feedback={resolved:true,correct,manual,title,body,model};
 announce(title);
 render(true);
}
function wordNormalize(t){return String(t).normalize('NFKC').toLowerCase().replace(/[’‘]/g,"'").replace(/[^a-z0-9\s']/gi,' ').replace(/\s+/g,' ').trim();}
function wordScore(actual,target){const a=wordNormalize(actual).split(' ').filter(Boolean),b=wordNormalize(target).split(' ').filter(Boolean);if(!b.length)return 0;const dp=Array.from({length:a.length+1},()=>Array(b.length+1).fill(0));for(let i=1;i<=a.length;i++)for(let j=1;j<=b.length;j++)dp[i][j]=a[i-1]===b[j-1]?dp[i-1][j-1]+1:Math.max(dp[i-1][j],dp[i][j-1]);return Math.round(100*dp[a.length][b.length]/Math.max(a.length,b.length));}
function nextStage(){if(!state.feedback?.resolved)return;stopSpeech();state.session.index++;if(state.session.index>=state.session.steps.length){finishSession();return;}resetStage();render();window.scrollTo(0,0);}
function finishSession(){const sess=state.session;if(sess.mode==='lesson'){
  const old=progress.completed[sess.lessonId];const score=sess.correct;
  if(!old||score>=old.score)progress.completed[sess.lessonId]={score,max:sessionTotalScorable(sess),doneAt:today()};
  saveProgress();
 }
 location.hash='#summary';render();window.scrollTo(0,0);
}
const sessionTotalScorable = sess=>sess.steps.length;
function renderExercise(){
 const sess=state.session;if(!sess)return renderHome();if(sess.index>=sess.steps.length)return renderSummary();const s=activeStep(),l=getLesson(s.lessonId),ex=getStepExercise(s),title=typeName(s.type),n=sess.index+1,total=sess.steps.length;
 let content='';
 if(s.type==='order'){
  const placed=state.selected.map(id=>state.bank.find(w=>w.id===id)).filter(Boolean);
  const unused=state.bank.filter(w=>!state.selected.includes(w.id));
  content=`<h1>رتّب الجملة بطريقة صحيحة</h1><p class="exercise-help">اضغط على الكلمات بالترتيب المناسب لتكوين جملة إنجليزية طبيعية.</p><div class="task-box"><span class="task-label">الموقف المطلوب</span>${esc(ex.prompt)}</div><div class="word-area ${placed.length?'':'empty'}" aria-label="الكلمات المختارة">${placed.length?placed.map((w,i)=>`<button class="word-chip placed" data-action="remove-word" data-pos="${i}" lang="en" aria-label="إزالة ${esc(w.text)}">${esc(w.text)}</button>`).join(''):'<span class="word-placeholder">اضغط على الكلمات في الأسفل لبناء الجملة</span>'}</div><div class="word-bank" aria-label="الكلمات المتاحة">${unused.map(w=>`<button class="word-chip" data-action="add-word" data-id="${w.id}" lang="en">${esc(w.text)}</button>`).join('')}</div>${state.feedback?'':`<div class="exercise-actions"><button class="btn btn-primary" data-action="check" ${placed.length!==state.bank.length?'disabled':''}>تحقق من الإجابة ${ico('check')}</button><button class="btn btn-subtle" data-action="clear-words" ${!placed.length?'disabled':''}>إعادة الترتيب</button></div>`}`;
 }else if(s.type==='dialogue'){
  // Previous correct replies provide the continuity of a multi-turn workplace conversation.
  const prior=l.dialogue.slice(0,s.index);const chat=[...prior.flatMap(d=>[{from:'other',text:d.other},{from:'you',text:d.options[d.correct]},{from:'other',text:d.reply}]),{from:'other',text:ex.other}];
  content=`<h1>كمّل المحادثة</h1><p class="exercise-help">اختر الرد الأكثر دقة ومهنية. المحادثة مستمرة من ردّك السابق.</p><div class="dialogue-window" aria-label="المحادثة باللغة الإنجليزية" lang="en">${chat.map(m=>`<div class="chat-row ${m.from==='you'?'you':''}">${m.from==='other'?'<span class="chat-avatar">C</span>':''}<span class="chat-bubble">${esc(m.text)}</span></div>`).join('')}${state.feedback?`<div class="chat-row you"><span class="chat-bubble">${esc(ex.options[ex.correct])}</span></div><div class="chat-row"><span class="chat-avatar">C</span><span class="chat-bubble">${esc(ex.reply)}</span></div>`:''}</div><div class="task-box chat-prompt"><span class="task-label">ماذا تقول الآن؟</span>${esc(ex.prompt)}</div><div class="choice-list">${ex.options.map((choice,i)=>`<button class="choice ${state.choice===i?'selected':''} ${state.feedback?i===ex.correct?'correct':state.choice===i?'wrong':'':''}" data-action="pick-choice" data-id="${i}" ${state.feedback?'disabled':''}><span class="choice-index">${i+1}</span><span>${esc(choice)}</span></button>`).join('')}</div>${state.feedback?'':`<div class="exercise-actions"><button class="btn btn-primary" data-action="check" ${state.choice===null?'disabled':''}>تحقق من الرد ${ico('check')}</button></div>`}`;
 }else if(s.type==='writing'){
  content=`<h1>اكتب الجملة بنفسك</h1><p class="exercise-help">تدرّب على صياغة المعنى. أكثر من إجابة قد تكون صحيحة لغويًا.</p><div class="task-box"><span class="task-label">عبّر بالإنجليزية عن المعنى التالي</span>${esc(ex.prompt)}</div><label class="sr-only" for="writing-input">إجابتك باللغة الإنجليزية</label><textarea id="writing-input" class="writing-input" maxlength="500" placeholder="Write your sentence here..." ${state.feedback?'disabled':''}>${esc(state.typed)}</textarea><p class="writing-hint">لن تُرسل إجابتك إلى خادم؛ المقارنة محلية مع صيغ نموذجية محددة.</p>${state.feedback||state.writingReview?'':`<div class="exercise-actions"><button class="btn btn-primary" data-action="check" ${state.typed.trim()?'':'disabled'}>راجع إجابتي ${ico('check')}</button></div>`}`;
 }else if(s.type==='listening'){
  const synthSupported='speechSynthesis' in window;
  content=`<h1>استمع وافهم المعنى</h1><p class="exercise-help">استمع للجملة كاملة، ثم أجب عن السؤال باللغة العربية.</p><div class="audio-board"><div class="audio-disc">${ico('volume',38)}</div><h3>استمع إلى حديث من بيئة العمل</h3><p>${synthSupported?'اختر سرعة القراءة التي تناسبك':'ميزة الصوت غير متاحة في هذا المتصفح'}</p><div class="audio-buttons">${synthSupported?`<button class="btn btn-dark" data-action="play-audio" data-speed="1">${ico('volume')} تشغيل الجملة</button><button class="btn btn-outline" data-action="play-audio" data-speed="0.8">تشغيل ببطء</button>`:''}<button class="btn btn-subtle" data-action="toggle-fallback">${state.fallback?'إخفاء النص':'عرض النص بدل الصوت'}</button></div>${state.fallback?`<div class="audio-fallback" lang="en">${esc(ex.spoken)}</div>`:''}${state.audioError?`<div class="notice" role="alert">${esc(state.audioError)}</div>`:''}</div><div class="task-box"><span class="task-label">سؤال الفهم</span>${esc(ex.prompt)}</div><div class="choice-list">${ex.options.map((op,i)=>`<button class="choice ${state.choice===i?'selected':''} ${state.feedback?i===ex.correct?'correct':state.choice===i?'wrong':'':''}" data-action="pick-choice" data-id="${i}" ${state.feedback?'disabled':''}><span class="choice-index">${i+1}</span><span dir="rtl" class="choice-ar">${esc(op)}</span></button>`).join('')}</div>${state.feedback?'':`<div class="exercise-actions"><button class="btn btn-primary" data-action="check" ${state.choice===null?'disabled':''}>تحقق من الفهم ${ico('check')}</button></div>`}`;
 }else if(s.type==='speaking'){
  const recSupported=!!(window.SpeechRecognition||window.webkitSpeechRecognition);
  content=`<h1>دورك تتكلم</h1><p class="exercise-help">استمع إلى الجملة ثم قلها بصوتك. المطلوب وضوح الكلام وطبيعته.</p><div class="task-box"><span class="task-label">النص الذي ستتدرب عليه</span>اقرأ الجملة التالية وكأنك تخاطب زميلًا في العمل.</div><div class="speech-phrase" lang="en">${esc(ex.phrase)}</div><div class="mic-area">${recSupported?`<button class="mic-button ${state.recording?'listening':''}" data-action="record" aria-label="${state.recording?'إيقاف الاستماع':'بدء التحدث'}" ${state.feedback?'disabled':''}>${ico('mic',29)}</button><p class="mic-help">${state.recording?'نستمع الآن... تكلم بالإنجليزية ثم توقف.':'اضغط الميكروفون وتحدث بالإنجليزية'}</p>`:'<p class="mic-help">التعرف على الصوت غير متاح في هذا المتصفح. يمكنك الاستماع وتكرار الجملة بنفسك.</p>'}<div class="audio-buttons"><button class="btn btn-outline" data-action="play-speak">${ico('volume')} استمع إلى المثال</button></div>${state.transcript?`<div class="speech-transcript" lang="en"><strong>النص الذي تعرّف عليه المتصفح:</strong><div>${esc(state.transcript)}</div></div>`:''}${state.speechError?`<div class="notice" role="alert">${esc(state.speechError)}</div>`:''}</div><div class="privacy-note">${ico('info',15)} التقييم هنا يقارن الكلمات التي فهمها المتصفح بالنص، ولا يقيس مخارج الحروف أو جودة النطق بدقة. قد يُعالَج الصوت عبر خدمة المتصفح الخارجية حسب إعداداته. لا يُخزّن الموقع تسجيلات صوتية.</div>${state.feedback?'':`<div class="exercise-actions"><button class="btn btn-outline" data-action="mark-practiced">تدرّبت على الجملة (بدون تقييم آلي)</button></div>`}`;
 }
 return `<div class="exercise-shell"><div class="exercise-top"><button class="back-link" data-action="leave-session">${ico('arrow',16)} إنهاء التدريب</button><span class="exercise-progress-label">${n} / ${total}</span></div><div class="progress-track" aria-label="تقدم الدرس"><i class="step-${n-1}"></i></div><div class="exercise-card"><div class="exercise-kind"><span class="kind-icon">${ico(typeIcon(s.type),17)}</span>${esc(title)} <span class="muted-small">· ${esc(l.title)}</span></div>${content}${state.writingReview&&s.type==='writing'?renderWritingReview(ex):''}${renderFeedback()}</div></div>`;
}
function renderFeedback(){const f=state.feedback;if(!f)return '';return `<div class="feedback ${f.manual?'':f.correct?'success':'warning'}" role="status"><h3>${f.correct?'✓ ':f.manual?'◌ ':'↗ '}${esc(f.title)}</h3><p>${esc(f.body)}</p>${f.model?`<div class="model-text" lang="en">${esc(f.model)}</div>`:''}<div class="exercise-actions"><button class="btn btn-primary" data-action="next-step">${state.session.index===state.session.steps.length-1?'عرض نتيجة التدريب':'المتابعة'} ${ico('arrow')}</button></div></div>`;}
function renderWritingReview(ex){return `<div class="feedback" role="status"><h3>هذه صيغة نموذجية، لكن إجابتك قد تكون صحيحة أيضًا</h3><p>لا يستطيع هذا الموقع التحقق من كل الصياغات الحرة تلقائيًا. قارن القاعدة والمعنى قبل اتخاذ القرار. ${esc(ex.note)}</p><div class="model-text" lang="en">${esc(ex.model)}</div><div class="exercise-actions"><button class="btn btn-primary" data-action="mark-manual">إجابتي صحيحة بعد المراجعة</button><button class="btn btn-outline" data-action="retry-writing">تعديل الإجابة</button><button class="btn btn-subtle" data-action="mark-wrong">أحتاج مراجعة هذه الصياغة</button></div></div>`;}
function renderSummary(){if(!state.session)return renderHome();const sess=state.session,percent=sess.attempts?Math.round(100*sess.correct/sess.attempts):0,next=nextLesson();return `<div class="summary-card"><div class="summary-emblem">✳</div><div class="eyebrow eyebrow-center">LESSON COMPLETE</div><h1>${sess.mode==='review'?'أنهيت جولة المراجعة':'أنهيت الدرس. أحسنت!'}</h1><p>المهم مو السرعة؛ المهم أنك قدرت تستخدم التعبير في جملة ومحادثة حقيقية.</p><div class="summary-score">${percent}% <small>دقة الإجابات التي تم تقييمها</small></div><div class="summary-grid"><div class="summary-stat"><strong>${sess.correct} / ${sess.attempts}</strong><span>إجابات مطابقة</span></div><div class="summary-stat"><strong>${sess.manual}</strong><span>تمارين راجعتها بنفسك</span></div></div><p class="muted-small">التمارين المنجزة ذاتيًا ليست ضمن نسبة الدقة.</p><div class="summary-actions"><button class="btn btn-primary" data-action="open-lesson" data-id="${next.id}">${sess.mode==='review'?'العودة إلى درس':'الدرس التالي'} ${ico('arrow')}</button><a href="#review" class="btn btn-outline">مراجعة الأخطاء</a><a href="#tracks" class="btn btn-subtle">المسارات</a></div></div>`;}
function renderReview(){const keys=Object.keys(progress.mistakes);return `<div class="page-title"><div class="eyebrow">LEARN FROM YOUR MISTAKES</div><h1>مراجعة الأخطاء</h1><p>لا تضيع الجمل التي أخطأت فيها. ارجع لها وجرّبها مرة ثانية.</p></div>${keys.length?`<div class="notice">لديك ${keys.length} ${keys.length===1?'تمرين يحتاج مراجعة':'تمارين تحتاج مراجعة'}. عند الإجابة الصحيحة يُحذف التمرين تلقائيًا من هذه القائمة.</div><div class="review-start"><button class="btn btn-primary" data-action="start-review">ابدأ مراجعة جميع الأخطاء ${ico('arrow')}</button></div><div class="review-list">${keys.map(key=>{const [lessonId,type,index]=key.split(':'),l=getLesson(lessonId);return `<div class="review-row"><div><h3>${esc(l.title)}</h3><p>${esc(getTrack(l.track).title)} · ${esc(localDate(progress.mistakes[key].date))}</p></div><span class="review-tag">${esc(typeName(type))}</span></div>`}).join('')}</div>`:`<div class="empty-state"><span class="empty-icon">${ico('check',28)}</span><h2>ما عندك أخطاء للمراجعة حاليًا</h2><p>أي تمرين تخطئ فيه سيظهر هنا لتتدرب عليه مرة ثانية.</p><a href="#tracks" class="btn btn-primary">استعرض المسارات ${ico('arrow')}</a></div>`}`;}
function renderProgress(){const done=Object.keys(progress.completed).length;return `<div class="page-title"><div class="eyebrow">YOUR LEARNING JOURNEY</div><h1>تقدمي في الإنجليزية</h1><p>مؤشرات بسيطة تساعدك تعرف أين وصلت وأين تحتاج المزيد من التدريب.</p></div><div class="progress-overview"><div class="metric-card"><div><div class="metric-label">إنجاز المسار</div><div class="metric-value">${done}<span class="metric-unit"> / 18</span></div></div></div><div class="metric-card"><div><div class="metric-label">دقة الإجابات</div><div class="metric-value">${accuracy()}<span class="metric-unit">%</span></div></div></div><div class="metric-card"><div><div class="metric-label">تمارين للمراجعة</div><div class="metric-value">${mistakeCount()}</div></div></div></div>${sectionHeading('الإنجاز حسب المسار','كل مسار يحتوي على 3 دروس')}<div class="progress-track-list">${tracks.map(t=>{const c=countDone(t.id);return `<a href="#track/${t.id}" class="progress-item"><div class="progress-item-top"><h3>${esc(t.title)}</h3><span>${c} / 3</span></div><div class="progress-track"><i class="bar-${Math.round(c/3*100)}"></i></div></a>`}).join('')}</div><div class="notice">${ico('lock',15)} تُحفظ بيانات تقدمك على هذا الجهاز باستخدام تخزين المتصفح فقط. لن تتزامن تلقائيًا مع جهاز آخر، وقد تُحذف إذا مسحت بيانات المتصفح.</div>`;}
function announce(str){live.textContent='';requestAnimationFrame(()=>{live.textContent=str;});}
function render(preserveScroll=false){
 const y=window.scrollY,route=currentRoute();if(!['practice','summary'].includes(route.name)&&state.recorder)stopSpeech();
 renderNav(route.name);
 switch(route.name){
 case'home':app.innerHTML=renderHome();break;
 case'tracks':app.innerHTML=renderTracks();break;
 case'track':app.innerHTML=renderTrack(route.id);break;
 case'lesson':app.innerHTML=renderOverview(route.id);break;
 case'review':app.innerHTML=renderReview();break;
 case'progress':app.innerHTML=renderProgress();break;
 case'practice':app.innerHTML=state.session?renderExercise():renderHome();break;
 case'summary':app.innerHTML=state.session?renderSummary():renderHome();break;
 default:app.innerHTML=renderHome();
 }
 if(preserveScroll)requestAnimationFrame(()=>window.scrollTo({top:y,behavior:'instant'}));
}
function checkAnswer(){const s=activeStep(),ex=getStepExercise(s);if(!s||state.feedback?.resolved)return;
 if(s.type==='order'){
  if(state.selected.length!==state.bank.length)return;
  const actual=state.selected.map(id=>state.bank.find(w=>w.id===id)?.text||'').join(' '),correct=wordNormalize(actual)===wordNormalize(ex.answer);
  setFeedback({correct,title:correct?'ترتيب صحيح!':'راجع ترتيب الكلمات',body:ex.note,model:correct?'':ex.answer});
 }else if(s.type==='dialogue'||s.type==='listening'){
  if(state.choice===null)return;const correct=state.choice===ex.correct;
  setFeedback({correct,title:correct?'رد مناسب للسياق!':'هذا الرد أنسب للموقف',body:ex.note,model:correct?'':s.type==='dialogue'?ex.options[ex.correct]:ex.spoken});
 }else if(s.type==='writing'){
  const val=byId('writing-input')?.value.trim()||'';state.typed=val;if(!val)return;
  const exact=[ex.model,...ex.variants].some(v=>wordNormalize(val)===wordNormalize(v));
  if(exact){state.writingReview=false;setFeedback({correct:true,title:'صياغة مطابقة للنموذج',body:ex.note,model:ex.model});}
  else{state.writingReview=true;render(true);}
 }
}
function speak(text,rate=1){
 if(!('speechSynthesis'in window)){announce('الصوت غير متاح في المتصفح');return;}
 try{window.speechSynthesis.cancel();state.audioError='';const u=new SpeechSynthesisUtterance(text);u.onerror=()=>{state.audioError='تعذر تشغيل الصوت. يمكنك اختيار «عرض النص بدل الصوت» ومتابعة التدريب.';if(activeStep()?.type==='listening')render(true);};u.lang='en-US';u.rate=rate;u.pitch=1;const voices=window.speechSynthesis.getVoices();const voice=voices.find(v=>v.lang==='en-US')||voices.find(v=>v.lang?.startsWith('en'));if(voice)u.voice=voice;window.speechSynthesis.speak(u);announce('جار تشغيل الجملة');}
 catch(_e){state.audioError='تعذر تشغيل الصوت على هذا الجهاز. يمكنك الاستمرار باستخدام النص.';state.speechError=state.audioError;render(true);}
}
function startRecognition(){const Recognition=window.SpeechRecognition||window.webkitSpeechRecognition;if(!Recognition){state.speechError='التعرف على الصوت غير مدعوم في هذا المتصفح.';render(true);return;}
 if(state.recording){try{state.recorder?.stop();}catch(_e){}return;}
 if(state.feedback?.resolved)return;
 try{
  const rec=new Recognition();state.recorder=rec;rec.lang='en-US';rec.interimResults=false;rec.maxAlternatives=3;rec.continuous=false;
  rec.onstart=()=>{state.recording=true;state.speechError='';render(true);};
  rec.onerror=e=>{state.recording=false;const messages={'not-allowed':'لم يُسمح بالوصول إلى الميكروفون. يمكنك التدرب يدويًا.','no-speech':'لم يسمع المتصفح كلامًا واضحًا. حاول مرة أخرى.',network:'خدمة التعرف الصوتي غير متاحة حاليًا. قد تحتاج إلى اتصال بالإنترنت.','audio-capture':'الميكروفون غير متاح على هذا الجهاز.',aborted:'أُلغي الاستماع.'};state.speechError=messages[e.error]||'تعذر التعرف على الكلام. حاول مرة أخرى أو أكمل التدريب يدويًا.';render(true);};
  rec.onend=()=>{state.recording=false;render(true);};
  rec.onresult=e=>{
   const phrase=getStepExercise(activeStep()).phrase;
   const choices=Array.from(e.results[0]||[]).map(x=>x.transcript);
   const best=choices.sort((a,b)=>wordScore(b,phrase)-wordScore(a,phrase))[0]||'';
   state.transcript=best;state.recording=false;
   const similarity=wordScore(best,phrase);
   if(similarity>=80){state.recorder=null;setFeedback({correct:true,title:`تطابق الكلمات ${similarity}%`,body:'تعرف المتصفح على معظم كلمات الجملة. هذه نتيجة للتعرف على الكلام وليست تقييمًا دقيقًا للنطق.',model:''});}
   else{state.speechError=`تعرف المتصفح على ${similarity}% من كلمات الجملة. جرّب مرة أخرى، أو أكمل التدريب يدويًا دون تقييم آلي.`;render(true);}
  };
  rec.start();
 }catch(_e){state.recording=false;state.speechError='تعذر بدء التعرف الصوتي. تحقق من إذن الميكروفون أو استخدم التدريب اليدوي.';render(true);}
}
function handleAction(action,button){
 const sess=state.session,s=activeStep(),ex=s?getStepExercise(s):null;
 switch(action){
  case'open-lesson':stopSpeech();state.session=null;state.writingReview=false;location.hash=`#lesson/${button.dataset.id}`;render();window.scrollTo(0,0);break;
  case'start-lesson':state.writingReview=false;startSession(button.dataset.id);break;
  case'leave-session':stopSpeech();state.writingReview=false;state.session=null;location.hash=sess?.mode==='review'?'#review':`#lesson/${sess?.lessonId}`;render();break;
  case'add-word':if(s?.type==='order'&&!state.feedback?.resolved){const id=Number(button.dataset.id);if(state.bank.some(w=>w.id===id)&&!state.selected.includes(id))state.selected.push(id);render(true);}break;
  case'remove-word':if(s?.type==='order'&&!state.feedback?.resolved){const n=Number(button.dataset.pos);if(Number.isInteger(n)&&n>=0&&n<state.selected.length)state.selected.splice(n,1);render(true);}break;
  case'clear-words':if(!state.feedback?.resolved){state.selected=[];render(true);}break;
  case'pick-choice':if(!state.feedback?.resolved&&s&&['dialogue','listening'].includes(s.type)){const i=Number(button.dataset.id);if(Number.isInteger(i)&&i>=0&&i<ex.options.length){state.choice=i;render(true);}}break;
  case'check':checkAnswer();break;
  case'retry-writing':state.writingReview=false;render(true);byId('writing-input')?.focus();break;
  case'mark-manual':if(s?.type==='writing'&&state.writingReview){state.writingReview=false;setFeedback({correct:false,manual:true,title:'سجلنا مراجعتك الذاتية',body:'أكملت التمرين بمراجعتك الشخصية، ولم نحتسبه إجابة صحيحة آليًا.',model:ex.model});}break;
  case'mark-wrong':if(s?.type==='writing'&&state.writingReview){state.writingReview=false;setFeedback({correct:false,title:'سنراجع هذه الصياغة لاحقًا',body:ex.note,model:ex.model});}break;
  case'next-step':state.writingReview=false;nextStage();break;
  case'play-audio':if(s?.type==='listening'){state.heard=true;speak(ex.spoken,Number(button.dataset.speed)||1);}break;
  case'toggle-fallback':if(s?.type==='listening'){state.fallback=!state.fallback;render(true);}break;
  case'play-speak':if(s?.type==='speaking')speak(ex.phrase,.87);break;
  case'record':if(s?.type==='speaking')startRecognition();break;
  case'mark-practiced':if(s?.type==='speaking'&&!state.feedback?.resolved){stopSpeech();setFeedback({correct:false,manual:true,title:'أنهيت التدريب الصوتي',body:'تم احتساب المشاركة دون تقييم نطق آلي. لإعادة المحاولة يمكنك فتح الدرس مجددًا.'});}break;
  case'start-review':{
   const steps=Object.keys(progress.mistakes).map(key=>{const [lessonId,type,index]=key.split(':');return {lessonId,type,index:Number(index)};}).filter(step=>getLesson(step.lessonId));
   if(steps.length){state.writingReview=false;startSession(steps[0].lessonId,'review',steps);}
   break;
  }
 }
}
app.addEventListener('click',event=>{
 const el=event.target.closest('[data-action]');if(!el||el.disabled)return;
 handleAction(el.dataset.action,el);
});
app.addEventListener('input',event=>{if(event.target.id==='writing-input'){
 state.typed=event.target.value;const btn=app.querySelector('[data-action="check"]');if(btn)btn.disabled=!state.typed.trim();
}});
app.addEventListener('keydown',event=>{if(event.key==='Enter'&&(event.ctrlKey||event.metaKey)&&event.target.id==='writing-input'){event.preventDefault();checkAnswer();}});
window.addEventListener('hashchange',()=>{stopSpeech();state.writingReview=false;render();window.scrollTo(0,0);});
window.addEventListener('pagehide',stopSpeech);
byId('date-label').textContent=new Date().toLocaleDateString('ar-SA',{day:'numeric',month:'long'});
document.querySelectorAll('[data-icon]').forEach(el=>el.innerHTML=ico(el.dataset.icon));
render();
