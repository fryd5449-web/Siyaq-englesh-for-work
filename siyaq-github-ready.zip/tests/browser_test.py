"""Optional real-browser acceptance checks. Requires Playwright + local server at 4173.

Run: python3 -m http.server 4173 & python3 tests/browser_test.py
In sandboxed/locked-down environments the browser can refuse local navigation.
"""
import re
import shutil
from playwright.sync_api import sync_playwright

URL = "http://127.0.0.1:4173/"

def normalize(text):
    return re.sub(r"[^a-z0-9']", "", text.lower().replace("’", "'"))

def order(page, target):
    for word in target.split():
        chips = page.locator('.word-bank .word-chip')
        choices = chips.all_text_contents()
        found = next((i for i, txt in enumerate(choices) if normalize(txt) == normalize(word)), None)
        assert found is not None, f"Missing word chip: {word!r} from {choices!r}"
        chips.nth(found).click()
    page.locator('[data-action="check"]').click()
    assert page.locator('.feedback.success').count() == 1, f"Incorrect order for {target}"
    page.locator('[data-action="next-step"]').click()

def choices(page, index):
    page.locator('.choice-list .choice').nth(index).click()
    page.locator('[data-action="check"]').click()
    assert page.locator('.feedback.success').count() == 1
    page.locator('[data-action="next-step"]').click()

def run():
    with sync_playwright() as p:
        launch_args = {'headless': True}
        system_chromium = shutil.which('chromium') or shutil.which('chromium-browser')
        if system_chromium:
            launch_args['executable_path'] = system_chromium
            launch_args['args'] = ['--no-sandbox']
        # On Windows/macOS, use Playwright-managed Chromium (`python -m playwright install chromium`).
        browser = p.chromium.launch(**launch_args)
        try:
            desktop = browser.new_page(viewport={'width': 1440, 'height': 900})
            errors=[]
            desktop.on('pageerror',lambda e: errors.append(str(e)))
            desktop.goto(URL, wait_until='networkidle')
            assert desktop.get_by_text('مو بس تفهم الإنجليزية.').is_visible()
            assert desktop.locator('.track-card').count() == 6
            desktop.locator('[data-action="open-lesson"]').first.click()
            assert desktop.locator('.concept-box').count() == 1
            lesson = desktop.evaluate("async () => (await import('/data.js')).getLesson('introductions')")
            desktop.locator('[data-action="start-lesson"]').click()
            for o in lesson['order']:
                order(desktop,o['answer'])
            for d in lesson['dialogue']:
                choices(desktop,d['correct'])
            desktop.locator('#writing-input').fill(lesson['writing']['model'])
            desktop.locator('[data-action="check"]').click()
            assert desktop.locator('.feedback.success').count()==1
            desktop.locator('[data-action="next-step"]').click()
            desktop.locator('[data-action="toggle-fallback"]').click()
            assert lesson['listening']['spoken'] in desktop.locator('#app').inner_text()
            choices(desktop,lesson['listening']['correct'])
            desktop.locator('[data-action="mark-practiced"]').click()
            desktop.locator('[data-action="next-step"]').click()
            assert desktop.locator('.summary-card').count() == 1
            desktop.reload(wait_until='networkidle')
            assert 'دروس أنهيتها' in desktop.locator('#app').inner_text()
            assert desktop.evaluate("JSON.parse(localStorage.getItem('siyaq-progress-v1')).completed.introductions !== undefined")
            desktop.goto(URL+'#progress')
            assert desktop.get_by_text('تقدمي في الإنجليزية').is_visible()
            assert not errors, errors
            mobile = browser.new_page(viewport={'width': 390, 'height': 844}, is_mobile=True, device_scale_factor=2, has_touch=True)
            mobile.goto(URL, wait_until='networkidle')
            assert mobile.locator('.mobile-nav').is_visible()
            assert mobile.locator('.track-card').count() == 6
            assert mobile.evaluate('document.documentElement.scrollWidth <= window.innerWidth + 2'), 'horizontal overflow on mobile'
            mobile.locator('[data-mobile-nav="tracks"]').click()
            assert mobile.get_by_text('مسارات الإنجليزية في العمل').is_visible()
            assert not errors, errors
            print('PASS: real Chromium desktop/mobile navigation, full lesson, feedback, persistence, safe layout.')
        finally:
            browser.close()

if __name__ == '__main__':
    run()
