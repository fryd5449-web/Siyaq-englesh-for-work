import assert from 'node:assert/strict';
import { tracks, lessons, getLesson, getTrack, lessonSteps } from '../data.js';
const tokenize=s=>s.toLowerCase().replace(/[’‘]/g,"'").replace(/[^a-z0-9\s']/gi,' ').split(/\s+/).filter(Boolean).sort().join(' ');
assert.equal(tracks.length,6,'six tracks');assert.equal(lessons.length,18,'18 lessons');
const ids=new Set();let checks=0;
for(const l of lessons){
 assert(!ids.has(l.id),`unique id ${l.id}`);ids.add(l.id);
 assert(getTrack(l.track),`track exists ${l.id}`);assert.equal(getLesson(l.id),l);
 assert(l.rule?.length>30 && l.objective?.length>20,`adequate teaching copy ${l.id}`);
 assert.equal(l.order.length,2,`${l.id} must have 2 ordering exercises`);
 assert.equal(l.dialogue.length,3,`${l.id} must have 3 conversation turns`);
 assert.equal(lessonSteps(l).length,8,`${l.id} must have 8 exercises`);
 for(const [i,o] of l.order.entries()){
  assert.equal(tokenize(o.words.join(' ')),tokenize(o.answer),`word bank matches target in ${l.id} order ${i}\nexpected: ${o.answer}\nfound:${o.words.join(' ')}`);
  assert(o.words.length>=6,`sentence is not a single word ${l.id}`);
  checks++;
 }
 for(const [i,d] of l.dialogue.entries()){
  assert.equal(d.options.length,3,`3 response options ${l.id}:${i}`);
  assert(Number.isInteger(d.correct)&&d.correct>=0&&d.correct<3,`valid correct response ${l.id}:${i}`);
  assert(d.other?.length>5&&d.reply?.length>5,`3-turn conversation ${l.id}:${i}`);
  checks++;
 }
 assert(l.writing.model.length>15&&Array.isArray(l.writing.variants),`writing examples ${l.id}`);
 assert.equal(l.listening.options.length,3);assert(l.listening.correct>=0 &&l.listening.correct<=2);
 assert(l.listening.spoken.length>30);assert(l.speaking.phrase.length>30);
 checks+=3;
}
console.log(`PASS: ${tracks.length} tracks; ${lessons.length} lessons; ${checks} validated exercises; unique IDs; ordering word banks.`);
