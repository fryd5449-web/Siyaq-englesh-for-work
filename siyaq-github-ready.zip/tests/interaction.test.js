import assert from 'node:assert/strict';
import vm from 'node:vm';
import {readFileSync} from 'node:fs';
import * as content from '../data.js';

// DOM-independent integration checks of the exact application controller.
// This is NOT a substitute for a real-browser compatibility/accessibility pass.
const elements={};
const app=elements.app={innerHTML:'',addEventListener(){},querySelector(){return null;}};
elements.announcer={textContent:''};elements['date-label']={textContent:''};elements['mistakes-count']={hidden:true,textContent:''};
elements['writing-input']={value:'',focus(){}};
const store=new Map();
const ctx={
 __testData:content,
 document:{getElementById:id=>elements[id]||null,querySelectorAll:()=>[]},
 window:{scrollY:0,scrollTo(){},addEventListener(){},speechSynthesis:{cancel(){},getVoices(){return []},speak(){}},SpeechRecognitionUtterance:null},
 localStorage:{getItem:k=>store.get(k)??null,setItem:(k,v)=>store.set(k,v)},
 location:{hash:'#home'},
 requestAnimationFrame:cb=>cb(),
 SpeechSynthesisUtterance:class{constructor(text){this.text=text}},
 console,
};
vm.createContext(ctx);
let src=readFileSync(new URL('../app.js',import.meta.url),'utf8');
src=src.replace(/^import \{ tracks, lessons, getLesson, getTrack, lessonSteps \} from '\.\/data\.js';/,"const {tracks, lessons, getLesson, getTrack, lessonSteps}=__testData;");
src+='\n;globalThis.__test={state,progress,render,handleAction,checkAnswer,wordNormalize,wordScore,startSession,activeStep,getStepExercise,markAttempt};';
vm.runInContext(src,ctx,{filename:'app.js'});
const a=ctx.__test;
const act=(action,data={})=>a.handleAction(action,{dataset:data,disabled:false});
const contains=txt=>assert(app.innerHTML.includes(txt),`missing expected UI text: ${txt}`);
const next=()=>act('next-step');
const answerOrder=(correct=true)=>{
 const ex=a.getStepExercise(a.activeStep());
 const words=ex.answer.split(/\s+/);
 const bank=a.state.bank;
 const ids=[];
 for (const word of words) {
  const item=bank.find(w=>a.wordNormalize(w.text)===a.wordNormalize(word)&&!ids.includes(w.id));
  assert(item,`word missing ${word}`);ids.push(item.id);
 }
 if(!correct)ids.reverse();
 for(const id of ids)act('add-word',{id:String(id)});
 assert(!a.state.feedback);act('check');assert(a.state.feedback?.resolved);
};
const answerChoice=(correct=true)=>{
 const ex=a.getStepExercise(a.activeStep());
 const index=correct?ex.correct:(ex.correct+1)%3;
 act('pick-choice',{id:String(index)});act('check');assert(a.state.feedback?.resolved);
};

contains('مو بس تفهم الإنجليزية');contains('18 درسًا');
ctx.location.hash='#tracks';a.render();contains('مسارات الإنجليزية');
ctx.location.hash='#track/everyday';a.render();contains('التعارف المهني');
ctx.location.hash='#lesson/introductions';a.render();contains('I work in sales.');
act('start-lesson',{id:'introductions'});assert.equal(ctx.location.hash,'#practice');contains('رتّب الجملة');
// First ordering mistake is retained for review, duplicate submission cannot inflate scores.
answerOrder(false);assert.equal(a.state.feedback.correct,false);
const attempts=a.progress.totals.attempts;act('check');assert.equal(a.progress.totals.attempts,attempts);
next();answerOrder(true);next();
answerChoice(false);assert.equal(a.state.feedback.correct,false);next();
answerChoice(true);next();answerChoice(true);next();
assert.equal(a.activeStep().type,'writing');
elements['writing-input'].value=a.getStepExercise(a.activeStep()).model;
act('check');assert(a.state.feedback.correct);next();
assert.equal(a.activeStep().type,'listening');act('toggle-fallback');contains('I recently joined');answerChoice(true);next();
assert.equal(a.activeStep().type,'speaking');act('mark-practiced');assert(a.state.feedback.manual);next();
assert.equal(ctx.location.hash,'#summary');assert(a.progress.completed.introductions);
assert.equal(a.progress.totals.manual,1);assert.equal(a.progress.totals.attempts,7);
assert.equal(a.progress.totals.correct,5);
assert.equal(Object.keys(a.progress.mistakes).length,2);
assert(store.has('siyaq-progress-v1'));
ctx.location.hash='#home';a.render();contains('دروس أنهيتها');
ctx.location.hash='#progress';a.render();contains('تقدمي في الإنجليزية');
ctx.location.hash='#review';a.render();contains('لديك 2');
act('start-review');assert.equal(a.state.session.mode,'review');
answerOrder(true);next();answerChoice(true);next();
assert.equal(ctx.location.hash,'#summary');assert.equal(Object.keys(a.progress.mistakes).length,0);
ctx.location.hash='#review';a.render();contains('ما عندك أخطاء للمراجعة');
// A valid alternate writing expression must work, and an unknown one must be self-reviewable.
act('start-lesson',{id:'requests'});
answerOrder(true);next();answerOrder(true);next();
for(let i=0;i<3;i++){answerChoice(true);next();}
assert.equal(a.activeStep().type,'writing');
elements['writing-input'].value='I have a perfectly different response that may be valid.';
act('check');assert(a.state.writingReview);contains('قد تكون صحيحة أيضًا');
act('mark-manual');assert(a.state.feedback.manual);next();
assert.equal(a.activeStep().type,'listening');
// The listening text is hidden by default and available as a fallback.
assert(!app.innerHTML.includes(a.getStepExercise(a.activeStep()).spoken));
act('toggle-fallback');assert(app.innerHTML.includes(a.getStepExercise(a.activeStep()).spoken));
answerChoice(true);next();
assert.equal(a.activeStep().type,'speaking');
// Simulate a WebSpeech transcript; this does not test an actual microphone or speech engine.
class FakeRecognition{
 constructor(){this.lang='';}
 start(){this.onstart?.();this.onresult?.({results:[[ {transcript:a.getStepExercise(a.activeStep()).phrase} ]]});}
 abort(){}
}
ctx.window.SpeechRecognition=FakeRecognition;
act('record');assert(a.state.feedback.correct);assert(a.state.feedback.title.includes('تطابق الكلمات'));next();
assert(a.progress.completed.requests);
assert(a.progress.totals.manual===2);
assert(a.progress.totals.correct<=a.progress.totals.attempts);
// Sanitization of browser-transcribed arbitrary text (whether or not a browser is supported).
ctx.location.hash='#practice';a.state.session.index=7;a.state.feedback=null;
a.state.transcript='<img src=x onerror=alert(1)>';a.render();
contains('&lt;img src=x onerror=alert(1)&gt;');
assert(!app.innerHTML.includes('<img src=x'));
assert.equal(a.wordScore('Could you send the report?', 'Could you send the report.'),100);
// Replay all 18 lessons through every step to catch progression and state errors.
for(const lesson of content.lessons){
 act('start-lesson',{id:lesson.id});
 answerOrder(true);next();answerOrder(true);next();
 for(let i=0;i<3;i++){answerChoice(true);next();}
 elements['writing-input'].value=lesson.writing.model;
 act('check');assert(a.state.feedback.correct,`writing failed in ${lesson.id}`);next();
 answerChoice(true);next();
 act('mark-practiced');next();
 assert.equal(ctx.location.hash,'#summary',`did not finish ${lesson.id}`);
 assert(a.progress.completed[lesson.id],`not saved ${lesson.id}`);
}
assert.equal(Object.keys(a.progress.completed).length,18);
console.log('PASS: route rendering, 2 sentence orders, 3-turn dialogues, writing, listening fallback, speaking transcript, all 18 end-to-end lesson flows, session scoring, persistence, mistake reviews, XSS escaping.');
